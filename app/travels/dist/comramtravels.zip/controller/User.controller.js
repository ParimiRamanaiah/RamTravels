sap.ui.define(["sap/ui/core/mvc/Controller"],e=>{"use strict";return e.extend("com.ram.travels.controller.User",{onInit(){}})});
//# sourceMappingURL=User.controller.js.map